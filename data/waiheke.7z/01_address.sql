--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = address, pg_catalog;

--
-- Data for Name: address; Type: TABLE DATA; Schema: address; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE address DISABLE TRIGGER ALL;

INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8000', 'Mango Rd Crescent Bulkage Control,  Lokko', NULL, '175c8162-99de-11e3-a9bd-1b6e9de69f63', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8001', '3rd Floor Sanyo Building, Apam', NULL, '175ea44c-99de-11e3-b468-5f94aa169284', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8002', 'The Land Corporation  Post offive Box 1, Niami', NULL, '175ecb5c-99de-11e3-87cf-7b867c2f87fd', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8003', 'State Housing Co. Ltd Box C352, Appertura', NULL, '175f197c-99de-11e3-be68-9704a7647bfe', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8004', 'Rana Real Estates & Mortgages Ltd', NULL, '175f679c-99de-11e3-8b58-cb7bda88e220', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8005', 'Rd 4 Box CT 400, Appertura', NULL, '175f8eac-99de-11e3-8676-1fe7da76ee71', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8006', 'Ascensor P O Box 6 Tempory', NULL, '175fdccc-99de-11e3-9dca-c799b50d1fa8', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8007', 'Building B P O BoxC6 Cantata', NULL, '176003dc-99de-11e3-ba10-e7fdb45b06dd', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8008', '4rd Floor Miami Close', NULL, '17605206-99de-11e3-bf4a-97c63cadf9b4', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8009', 'Drift Lane No. 55, Aputa', NULL, '1760a026-99de-11e3-8ab2-57192bdd0771', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8010', '2nd Piano, RM 1007, Ramorse', NULL, '1760a026-99de-11e3-80d9-cfe40076c561', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8011', 'Plazar 5000 Avenue Link', NULL, '1760c736-99de-11e3-821f-0706a7d7983f', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8012', 'Habour View Box 5 Taropoli', NULL, '1760ee46-99de-11e3-a626-8b8db11f362f', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8013', 'Disco 5 Box DT 100, Yermani', NULL, '17611556-99de-11e3-8f61-9fae46a14aa4', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8014', 'Dangling Ring Box 44, Tapoli', NULL, '17611556-99de-11e3-9699-173299de9572', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8015', 'Plant Pool No4 Asutare', NULL, '17613c66-99de-11e3-b304-c3d1ff78dc07', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8016', 'Clinic Block 3, Asutare', NULL, '17616376-99de-11e3-ba19-cb4cdb01bfd7', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8017', 'Vivid Coops Ave Platino', NULL, '17616376-99de-11e3-bdcf-6b1b957a8ec4', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8018', 'Box CT 43 Koftwon Lane', NULL, '17618a86-99de-11e3-b837-fb9a17243aec', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8019', 'Vaventino BOX 678, Ramorse', NULL, '1761b196-99de-11e3-840e-8fb2e7dd3c7b', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('8020', '1st Floor Odum Street Opumar', NULL, '1761d8a6-99de-11e3-b709-f72a10c2c40e', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9000', 'Building B P O BoxC6 Cantata', NULL, '1761d8a6-99de-11e3-870e-37b56637b2ac', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9001', '4rd Floor Miami Close', NULL, '1761ffb6-99de-11e3-b38e-5b4b4c404438', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9002', 'Drift Lane No. 55, Aputa', NULL, '176226c6-99de-11e3-8923-8f3256ac7b81', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9003', '2nd Piano, RM 1007, Ramorse', NULL, '176226c6-99de-11e3-99b5-0729f1281a60', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9004', 'Plazar 5000 Avenue Link', NULL, '17624dd6-99de-11e3-bd12-5f98296b6991', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9005', 'Habour View Box 5 Taropoli', NULL, '176274e6-99de-11e3-bf8e-a3375a05c8c6', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9006', 'Disco 5 Box DT 100, Yermani', NULL, '176274e6-99de-11e3-a42e-d30297b7deaf', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9007', 'Dangling Ring Box 44, Tapoli', NULL, '17629bf6-99de-11e3-8dfe-3f4444620831', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9008', 'Plant Pool No4 Asutare', NULL, '1762c306-99de-11e3-86e3-23d84ad97fa3', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9009', 'Clinic Block 3, Asutare', NULL, '1762c306-99de-11e3-bb62-bbc2c6e74def', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9010', 'Vivid Coops Ave Platino', NULL, '1762ea16-99de-11e3-a1e4-938c936849da', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9011', 'Box CT 43 Koftwon Lane', NULL, '17631130-99de-11e3-a190-db4f8beefb1e', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9012', 'Vaventino BOX 678, Ramorse', NULL, '17631130-99de-11e3-abeb-f3cf4577f58c', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9013', 'Mango Rd Crescent Bulkage Control,  Lokko', NULL, '17633840-99de-11e3-b2d5-775c5dd29acc', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9014', '3rd Floor Sanyo Building, Apam', NULL, '17635f50-99de-11e3-b2df-1b9af4de71a8', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9015', 'The Land Corporation  Post offive Box 1, Niami', NULL, '17635f50-99de-11e3-8bb5-6304d9dddf2f', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9016', 'State Housing Co. Ltd Box C352, Appertura', NULL, '17638660-99de-11e3-a7ac-5ff99a94a3aa', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9017', 'Rana Real Estates & Mortgages Ltd', NULL, '1763ad70-99de-11e3-90c0-539743867b68', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9018', 'Rd 4 Box CT 400, Appertura', NULL, '1763ad70-99de-11e3-a040-dfea7505a109', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9019', 'Ascensor P O Box 6 Tempory', NULL, '1763d480-99de-11e3-94a3-eb3a2b41a341', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('9020', 'P O Box NK300 Samopman', NULL, '1763d480-99de-11e3-9c52-13b8d2a17e9b', 1, 'i', 'db:postgres', '2014-02-20 16:21:30.476');


ALTER TABLE address ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

